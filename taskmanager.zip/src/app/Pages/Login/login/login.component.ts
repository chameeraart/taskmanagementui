import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router // Inject Angular Router
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {

    const { username, password } = this.loginForm.value;
    console.log('Username:', username);
    console.log('Password:', password);

    if(username !="" && password !="")
    {
      this.router.navigate(['/task']);
    }
    else
    {
      alert("please enter username and password")
    }


  }
}
