import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../../task.service';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  submitted = false;
  loading = false;
  error = '';
  tasks: any[] = [];
  editTasks: any = null;

  // Define task as a FormGroup
  task: FormGroup;

  constructor(private fb: FormBuilder, private api: TaskService, private tostr: ToastrService) { }

  ngOnInit() {
    // Initialize the form group with form controls
    this.initFormgroup()

    this.GetTasks();
  }


  initFormgroup(){
    this.task = this.fb.group({
      Id: [0],
      Title: ['', Validators.required],
      Description: ['', Validators.required],
      DueDate: ['', Validators.required]
    });

  }


  GetTasks(){
    this.loading = true;
    this.api.getsaveTaskAll().subscribe(result=>{
      this.tasks = Object.assign([],result);  
      this.loading = false;
    })
  }

  LoadData(){
    this.task = this.fb.group({
      Id: [this.editTasks.id],
      Title: [this.editTasks.title],
      Description: [this.editTasks.description],
      DueDate: [this.convertToDate(this.editTasks.dueDate)]
    });
  }

  convertToDate(dateString: string): string {
    // Assuming dateString is in the format "yyyy-MM-ddTHH:mm:ss"
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // Convert date to "yyyy-MM-dd" format
  }
  
//Save The Task
  submitForm() {
    this.submitted = true;
    // Check if the form is invalid
    if (this.task.invalid) {
      this.tostr.error('Please fill out all  fields.');
      return;
    }

    this.loading = true; // Set loading to true before making the API call
    this.api.saveTask(this.task.value).subscribe(
      result => {
        this.tostr.success("Task Details Saved Successfully");
        this.loading = false;
        this.task.reset(); // Reset the form after successful submission
        this.GetTasks();
        this.initFormgroup();
      },
      (error: HttpErrorResponse) => {
        this.tostr.error("An error occurred while saving task details");
        this.loading = false;
        console.error(error);
      }
    );
    
  }

  //Edit Selected Record
  onEdit(id: number) {
    console.log(id)
    this.loading = true;
    this.api.getTask(id).subscribe(result => {
      this.editTasks = Object.assign([], result);
      console.log(this.editTasks)
       this.LoadData();
       this.loading = false;
    })
  }

  //Delete the Selected Record
  onDelete(id: number) {
    if (confirm('Are You Sure To Delete This Record?')) {
      this.api.deleteask(id).subscribe(
        result => {
          this.tostr.success("Delete Task Successfully");
          this.GetTasks();
          // Optionally, you can perform any additional actions after successful deletion
        },
        (error: HttpErrorResponse) => {
          this.loading = false;
        }
      );
     
    }
    
  }

  //Reset the form
  clear(){
    this.task.reset(); // Reset the form
  }

}
