export const config = {
     apiUrl: 'https://localhost:7019'
};