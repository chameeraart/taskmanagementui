import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, tap } from 'rxjs';
import { config } from './config';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$(){
    return this._refreshNeeded$;
  }

  saveTask(task: any): Observable<any> {
    console.log("task",task)
    return this.http.post<any>(`${config.apiUrl}/Task/create`,task);  
  }

  getsaveTaskAll(){
    return this.http.get<any>(`${config.apiUrl}/Task/getAll`);  
  }
  
  getTask(Id: number){
    return this.http.get<any>(`${config.apiUrl}/Task/get/` +Id);  
  }
  
  deleteask(Id: number){
    return this.http.get<any>(`${config.apiUrl}/Task/delete/` +Id).pipe(
      tap(()=>{
        this._refreshNeeded$.next();
      })
    ); 
  }

}
